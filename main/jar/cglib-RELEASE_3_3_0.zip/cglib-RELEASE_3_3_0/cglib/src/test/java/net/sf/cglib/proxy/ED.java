package net.sf.cglib.proxy;

public class ED {
	private Long id;
	private float amount;

	public float getAmount() {
		return amount;
	}

	public Long getId() {
		return id;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public void setId(Long id) {
		this.id = id;
	}
}

