package net.sf.cglib.proxy;

public interface DI1 {
    public String herby();
}
