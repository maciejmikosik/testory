package net.sf.cglib.proxy;

class D3 extends D2 implements DI3 {
    public String extra() {
        return "D3";
    }
}
